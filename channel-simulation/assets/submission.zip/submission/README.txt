To run the code, run the following command in the terminal:
java -jar simulation.jar -Xmx4096m

You will need to have the latest version of Java for the code to run, otherwise you will get an exception.
